module.exports = {
  bail: true,
  coverageThreshold: {
    global: {
      branches: 100,
      statements: 100,
    },
  },
};
